
const REGIONES = {
  'Región Metropolitana': ['Santiago','Maipú','Puente Alto','La Florida'],
  'Valparaíso': ['Valparaíso','Viña del Mar','Quilpué','Concón']
};
