
const CLP = (n)=> n.toLocaleString('es-CL',{style:'currency', currency:'CLP'});
