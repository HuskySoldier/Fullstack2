
const $ = (s, sc=document)=> sc.querySelector(s);
const $$ = (s, sc=document)=> sc.querySelectorAll(s);
